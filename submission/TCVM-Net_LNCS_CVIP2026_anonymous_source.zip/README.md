# TCVM-Net Anonymous LNCS Submission Source

This package contains the anonymous Springer LNCS manuscript source and only
the tables and figures required to compile it.

## Compile

Run from the `paper` directory with a LaTeX installation that includes the
Springer `llncs` class:

```text
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The resulting `main.pdf` is the 15-page anonymous submission manuscript.

## Contents

```text
paper/
  main.tex
  references.bib
  figures/
  tables/
outputs/
  figures/
```

Generated experiment tables are included as LaTeX fragments under
`paper/tables`. The three manuscript visualizations loaded from experiment
outputs are included under `outputs/figures`.
